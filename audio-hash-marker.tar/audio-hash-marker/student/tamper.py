#!/usr/bin/env python3
import sys
import wave

MARKER = b"AUDIO_SELF_MARK|"
HASH_HEX_LENGTH = 64


def bits_to_bytes(bits):
    data = bytearray()

    for i in range(0, len(bits), 8):
        chunk = bits[i:i + 8]

        if len(chunk) < 8:
            break

        value = 0
        for bit in chunk:
            value = (value << 1) | bit

        data.append(value)

    return bytes(data)


def extract_lsb_bytes(frame_bytes: bytes) -> bytes:
    bits = []

    for b in frame_bytes:
        bits.append(b & 1)

    return bits_to_bytes(bits)


def find_hash_bit_position(frame_bytes: bytes) -> int:
    data = extract_lsb_bytes(frame_bytes)

    marker_start = data.find(MARKER)

    if marker_start == -1:
        raise ValueError("Marker not found")

    message_start = marker_start + len(MARKER)
    delimiter_pos = data.find(b"|", message_start)

    if delimiter_pos == -1:
        raise ValueError("Message delimiter not found")

    hash_start = delimiter_pos + 1

    if hash_start + HASH_HEX_LENGTH > len(data):
        raise ValueError("Hash field not complete")

    # Chọn bit cuối cùng của byte đầu tiên trong hash để chỉ làm hỏng hash,
    # còn marker và message vẫn giữ nguyên.
    target_lsb_byte_index = hash_start
    target_bit_position = target_lsb_byte_index * 8 + 7

    return target_bit_position


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 tamper.py <input.wav> <tampered.wav>")
        sys.exit(1)

    input_wav = sys.argv[1]
    output_wav = sys.argv[2]

    with wave.open(input_wav, "rb") as wav:
        params = wav.getparams()
        frames = bytearray(wav.readframes(wav.getnframes()))

    target_position = find_hash_bit_position(frames)

    if target_position >= len(frames):
        print("ERROR: target position outside audio data")
        sys.exit(2)

    frames[target_position] ^= 1

    with wave.open(output_wav, "wb") as wav:
        wav.setparams(params)
        wav.writeframes(bytes(frames))

    print("TAMPER_OK")
    print(f"modified_lsb_position={target_position}")
    print(f"output={output_wav}")


if __name__ == "__main__":
    main()
