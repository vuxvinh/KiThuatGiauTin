# Lab: Giấu tin trong audio + tự đánh dấu bằng mã hash

## 1. Mục tiêu

Trong bài lab này, bạn cần hoàn thành 3 task:

- Task 1: Nhúng thông điệp bí mật vào file audio.
- Task 2: Trích xuất thông điệp bí mật từ file audio.
- Task 3: Chỉnh sửa nhẹ file audio đã giấu tin và kiểm tra tính toàn vẹn bằng SHA-256.

## 2. Ý tưởng

Thông điệp bí mật trước khi nhúng sẽ được đóng gói theo dạng:

```text
MARKER|MESSAGE|SHA256(MESSAGE)
```

Marker sử dụng trong bài:

```text
AUDIO_SELF_MARK
```

Ví dụ:

```text
AUDIO_SELF_MARK|this is a secret|<sha256_hex>
```

Trong đó `SHA256(MESSAGE)` là mã băm SHA-256 của message.

## 3. Kỹ thuật LSB trong audio

File WAV chứa dữ liệu âm thanh dưới dạng các byte. Mỗi byte có 8 bit. Ta có thể giấu 1 bit dữ liệu vào bit cuối cùng của mỗi byte âm thanh.

Ví dụ:

```text
Byte ban đầu:    10110110
Muốn giấu bit 1: 10110111
Muốn giấu bit 0: 10110110
```

Do chỉ thay đổi bit cuối cùng nên âm thanh sau khi nhúng tin gần như không thay đổi khi nghe.

## 4. Nhiệm vụ

Bạn cần hoàn thiện hai file:

```text
embed.py
extract.py
```

File `tamper.py` đã được cung cấp để mô phỏng việc chỉnh sửa nhẹ dữ liệu đã giấu trong audio.

Lưu ý: `output.wav` và `tampered.wav` không có sẵn lúc bắt đầu. Hai file này sẽ được tạo ra sau khi bạn chạy đúng các lệnh trong task.

## 5. Cách chạy từng task

Task 1: Nhúng tin

```bash
python3 embed.py input.wav output.wav "this is a secret"
```

Kết quả đúng cần có:

```text
EMBED_OK
```

Task 2: Trích xuất tin

```bash
python3 extract.py output.wav
```

Kết quả đúng cần có:

```text
Marker: AUDIO_SELF_MARK
Message: this is a secret
Hash check: OK
```

Task 3: Chỉnh sửa file audio và kiểm tra lại

```bash
python3 tamper.py output.wav tampered.wav
python3 extract.py tampered.wav
```

Kết quả mong muốn:

```text
Marker: AUDIO_SELF_MARK
Message: this is a secret
Hash check: FAILED
```

Điều này chứng minh rằng file vẫn còn marker tự đánh dấu, nhưng dữ liệu hash đã bị thay đổi nên kiểm tra toàn vẹn thất bại.

## 6. Chạy kiểm tra tự động

Sau khi hoàn thành, chạy:

```bash
bash check_work.sh
```

Nếu đúng, bạn sẽ thấy:

```text
TASK1_EMBED_PASS
TASK2_EXTRACT_PASS
TASK3_TAMPER_DETECTED_PASS
ALL_TASKS_PASS
```
