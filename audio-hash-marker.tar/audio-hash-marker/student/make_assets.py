#!/usr/bin/env python3
import math
import struct
import wave

SAMPLE_RATE = 44100
DURATION_SECONDS = 3
FREQUENCY = 440.0
AMPLITUDE = 12000


def main():
    output_file = "input.wav"

    with wave.open(output_file, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(SAMPLE_RATE)

        for i in range(SAMPLE_RATE * DURATION_SECONDS):
            t = i / SAMPLE_RATE
            value = int(AMPLITUDE * math.sin(2 * math.pi * FREQUENCY * t))
            wav.writeframes(struct.pack("<h", value))

    print("Created input.wav")


if __name__ == "__main__":
    main()
