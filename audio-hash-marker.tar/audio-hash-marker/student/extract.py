#!/usr/bin/env python3
import hashlib
import sys
import wave

MARKER = "AUDIO_SELF_MARK"
DELIMITER = "|"
HASH_HEX_LENGTH = 64


def bits_to_bytes(bits):
    """
    TODO:
    Gom mỗi 8 bit thành 1 byte.
    Bit đầu tiên là bit có trọng số cao nhất.
    """
    raise NotImplementedError("TODO: bits_to_bytes")


def extract_lsb_bytes(frame_bytes: bytes) -> bytes:
    """
    TODO:
    Lấy LSB của từng byte âm thanh.
    Sau đó gom lại thành bytes.
    """
    raise NotImplementedError("TODO: extract_lsb_bytes")


def parse_payload(data: bytes):
    """
    TODO:
    Tìm payload có dạng:
    AUDIO_SELF_MARK|MESSAGE|HASH

    Gợi ý:
    - Tìm chuỗi b"AUDIO_SELF_MARK|"
    - Sau marker, tìm dấu | tiếp theo để lấy MESSAGE
    - Sau dấu | thứ hai, đọc 64 ký tự hash
    - Trả về marker, message, embedded_hash
    """
    raise NotImplementedError("TODO: parse_payload")


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 extract.py <audio.wav>")
        sys.exit(1)

    input_wav = sys.argv[1]

    with wave.open(input_wav, "rb") as wav:
        frames = wav.readframes(wav.getnframes())

    data = extract_lsb_bytes(frames)

    try:
        marker, message, embedded_hash = parse_payload(data)
    except ValueError as e:
        print("Marker found: NO")
        print(f"ERROR: {e}")
        sys.exit(3)

    calculated_hash = hashlib.sha256(message.encode()).hexdigest()

    print("Marker found: YES")
    print(f"Marker: {marker}")
    print(f"Message: {message}")
    print(f"Embedded hash: {embedded_hash}")
    print(f"Calculated hash: {calculated_hash}")

    if calculated_hash == embedded_hash:
        print("Hash check: OK")
    else:
        print("Hash check: FAILED")


if __name__ == "__main__":
    main()
