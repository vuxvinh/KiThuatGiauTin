#!/bin/bash
set -u

echo "===== AUDIO HASH MARKER LAB CHECK ====="
echo

TASK1=0
TASK2=0
TASK3=0

MESSAGE="this is a secret"

rm -f output.wav tampered.wav
rm -f embed.log extract.log tamper.log tampered_extract.log

echo "[Task 1] Embed secret message into input.wav"
python3 embed.py input.wav output.wav "$MESSAGE" > embed.log 2>&1
EMBED_STATUS=$?

if [ $EMBED_STATUS -eq 0 ] \
   && [ -f output.wav ] \
   && grep -q "EMBED_OK" embed.log; then
    echo "TASK1_EMBED_PASS"
    TASK1=1
else
    echo "TASK1_EMBED_FAIL"
fi

echo
echo "[Task 2] Extract message and verify hash"
python3 extract.py output.wav > extract.log 2>&1
EXTRACT_STATUS=$?

if [ $EXTRACT_STATUS -eq 0 ] \
   && grep -q "Marker found: YES" extract.log \
   && grep -q "Marker: AUDIO_SELF_MARK" extract.log \
   && grep -q "Message: this is a secret" extract.log \
   && grep -q "Hash check: OK" extract.log; then
    echo "TASK2_EXTRACT_PASS"
    TASK2=1
else
    echo "TASK2_EXTRACT_FAIL"
fi

echo
echo "[Task 3] Tamper audio and detect integrity failure"
python3 tamper.py output.wav tampered.wav > tamper.log 2>&1
TAMPER_STATUS=$?

python3 extract.py tampered.wav > tampered_extract.log 2>&1
TAMPER_EXTRACT_STATUS=$?

if [ $TAMPER_STATUS -eq 0 ] \
   && [ -f tampered.wav ] \
   && grep -q "TAMPER_OK" tamper.log \
   && grep -q "Marker found: YES" tampered_extract.log \
   && grep -q "Marker: AUDIO_SELF_MARK" tampered_extract.log \
   && grep -q "Message: this is a secret" tampered_extract.log \
   && grep -q "Hash check: FAILED" tampered_extract.log; then
    echo "TASK3_TAMPER_DETECTED_PASS"
    TASK3=1
else
    echo "TASK3_TAMPER_DETECTED_FAIL"
fi

echo
echo "===== TASK SUMMARY ====="
echo "task1_embed=$TASK1"
echo "task2_extract=$TASK2"
echo "task3_tamper_detected=$TASK3"

echo
if [ $TASK1 -eq 1 ] \
   && [ $TASK2 -eq 1 ] \
   && [ $TASK3 -eq 1 ]; then
    echo "ALL_TASKS_PASS"
else
    echo "SOME_TASKS_FAIL"
fi
