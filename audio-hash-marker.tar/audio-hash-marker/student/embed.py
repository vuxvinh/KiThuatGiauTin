#!/usr/bin/env python3
import hashlib
import sys
import wave

MARKER = "AUDIO_SELF_MARK"
DELIMITER = "|"


def bytes_to_bits(data: bytes):
    """
    Chuyển bytes thành từng bit.
    Mỗi byte được đọc từ bit cao nhất đến bit thấp nhất.
    """
    for byte in data:
        for shift in range(7, -1, -1):
            yield (byte >> shift) & 1


def build_payload(message: str) -> bytes:
    """
    TODO:
    Tạo payload theo định dạng:
    MARKER|MESSAGE|SHA256(MESSAGE)

    Gợi ý:
    - Không cho phép message chứa ký tự |
    - Hash dùng hashlib.sha256(message.encode()).hexdigest()
    - Trả về dữ liệu dạng bytes
    """
    raise NotImplementedError("TODO: build_payload")


def embed_bits_into_audio(frame_bytes: bytes, payload: bytes) -> bytes:
    """
    TODO:
    Nhúng payload vào LSB của từng byte âm thanh.

    Gợi ý:
    - Chuyển frame_bytes sang bytearray
    - Chuyển payload thành danh sách bit
    - Với mỗi bit, sửa LSB của frame byte tương ứng
    - Công thức sửa LSB:
      audio[i] = (audio[i] & 0xFE) | bit
    """
    raise NotImplementedError("TODO: embed_bits_into_audio")


def main():
    if len(sys.argv) != 4:
        print('Usage: python3 embed.py <input.wav> <output.wav> "<message>"')
        sys.exit(1)

    input_wav = sys.argv[1]
    output_wav = sys.argv[2]
    message = sys.argv[3]

    payload = build_payload(message)

    with wave.open(input_wav, "rb") as wav:
        params = wav.getparams()
        frames = wav.readframes(wav.getnframes())

    capacity_bits = len(frames)
    required_bits = len(payload) * 8

    if required_bits > capacity_bits:
        print("ERROR: Message too large for this audio file")
        print(f"required_bits={required_bits}")
        print(f"capacity_bits={capacity_bits}")
        sys.exit(2)

    modified_frames = embed_bits_into_audio(frames, payload)

    with wave.open(output_wav, "wb") as wav:
        wav.setparams(params)
        wav.writeframes(modified_frames)

    print("EMBED_OK")
    print(f"marker={MARKER}")
    print(f"message={message}")
    print(f"payload_bytes={len(payload)}")
    print(f"required_bits={required_bits}")
    print(f"capacity_bits={capacity_bits}")
    print(f"output={output_wav}")


if __name__ == "__main__":
    main()
