#!/usr/bin/env python3
import hashlib
import sys
import wave

MARKER = "AUDIO_SELF_MARK"
DELIMITER = "|"


def bytes_to_bits(data: bytes):
    for byte in data:
        for shift in range(7, -1, -1):
            yield (byte >> shift) & 1


def build_payload(message: str) -> bytes:
    if DELIMITER in message:
        raise ValueError("Message must not contain the | delimiter")

    digest = hashlib.sha256(message.encode()).hexdigest()
    payload = f"{MARKER}{DELIMITER}{message}{DELIMITER}{digest}"
    return payload.encode()


def embed_bits_into_audio(frame_bytes: bytes, payload: bytes) -> bytes:
    audio = bytearray(frame_bytes)
    bits = list(bytes_to_bits(payload))

    if len(bits) > len(audio):
        raise ValueError("Payload is too large for this audio file")

    for i, bit in enumerate(bits):
        audio[i] = (audio[i] & 0xFE) | bit

    return bytes(audio)


def main():
    if len(sys.argv) != 4:
        print('Usage: python3 embed.py <input.wav> <output.wav> "<message>"')
        sys.exit(1)

    input_wav = sys.argv[1]
    output_wav = sys.argv[2]
    message = sys.argv[3]

    payload = build_payload(message)

    with wave.open(input_wav, "rb") as wav:
        params = wav.getparams()
        frames = wav.readframes(wav.getnframes())

    capacity_bits = len(frames)
    required_bits = len(payload) * 8

    if required_bits > capacity_bits:
        print("ERROR: Message too large for this audio file")
        print(f"required_bits={required_bits}")
        print(f"capacity_bits={capacity_bits}")
        sys.exit(2)

    modified_frames = embed_bits_into_audio(frames, payload)

    with wave.open(output_wav, "wb") as wav:
        wav.setparams(params)
        wav.writeframes(modified_frames)

    print("EMBED_OK")
    print(f"marker={MARKER}")
    print(f"message={message}")
    print(f"payload_bytes={len(payload)}")
    print(f"required_bits={required_bits}")
    print(f"capacity_bits={capacity_bits}")
    print(f"output={output_wav}")


if __name__ == "__main__":
    main()
