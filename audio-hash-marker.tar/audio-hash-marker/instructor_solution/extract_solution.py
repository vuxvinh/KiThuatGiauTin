#!/usr/bin/env python3
import hashlib
import sys
import wave

MARKER = "AUDIO_SELF_MARK"
DELIMITER = "|"
HASH_HEX_LENGTH = 64


def bits_to_bytes(bits):
    data = bytearray()

    for i in range(0, len(bits), 8):
        chunk = bits[i:i + 8]

        if len(chunk) < 8:
            break

        value = 0
        for bit in chunk:
            value = (value << 1) | bit

        data.append(value)

    return bytes(data)


def extract_lsb_bytes(frame_bytes: bytes) -> bytes:
    bits = []

    for b in frame_bytes:
        bits.append(b & 1)

    return bits_to_bytes(bits)


def parse_payload(data: bytes):
    marker_prefix = f"{MARKER}{DELIMITER}".encode()
    marker_start = data.find(marker_prefix)

    if marker_start == -1:
        raise ValueError("Marker not found")

    message_start = marker_start + len(marker_prefix)
    delimiter_pos = data.find(DELIMITER.encode(), message_start)

    if delimiter_pos == -1:
        raise ValueError("Message delimiter not found")

    hash_start = delimiter_pos + 1
    hash_end = hash_start + HASH_HEX_LENGTH

    if hash_end > len(data):
        raise ValueError("Hash field not complete")

    message = data[message_start:delimiter_pos].decode()
    embedded_hash = data[hash_start:hash_end].decode()

    if len(embedded_hash) != HASH_HEX_LENGTH:
        raise ValueError("Invalid hash length")

    return MARKER, message, embedded_hash


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 extract.py <audio.wav>")
        sys.exit(1)

    input_wav = sys.argv[1]

    with wave.open(input_wav, "rb") as wav:
        frames = wav.readframes(wav.getnframes())

    data = extract_lsb_bytes(frames)

    try:
        marker, message, embedded_hash = parse_payload(data)
    except ValueError as e:
        print("Marker found: NO")
        print(f"ERROR: {e}")
        sys.exit(3)

    calculated_hash = hashlib.sha256(message.encode()).hexdigest()

    print("Marker found: YES")
    print(f"Marker: {marker}")
    print(f"Message: {message}")
    print(f"Embedded hash: {embedded_hash}")
    print(f"Calculated hash: {calculated_hash}")

    if calculated_hash == embedded_hash:
        print("Hash check: OK")
    else:
        print("Hash check: FAILED")


if __name__ == "__main__":
    main()
