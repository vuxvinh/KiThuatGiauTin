#!/bin/bash
set -u

if [ "${CHECK_WORK_CAPTURED:-0}" != "1" ]; then
    mkdir -p "$HOME/.local/result"
    CHECK_WORK_CAPTURED=1 bash "$0" "$@" | tee "$HOME/.local/result/task_results.txt"
    exit ${PIPESTATUS[0]}
fi

echo "===== LSB SECRET HEADER LAB CHECK ====="
echo

TASK1=0
TASK2=0
TASK3=0
TASK4=0
TASK5=0
TASK6=0

rm -f encoded.png recovered.txt recovered_empty.txt encode.log decode.log no_header.log

echo "[Task 1] Encode secret.txt into cover.png"
python3 encode.py cover.png secret.txt encoded.png > encode.log 2>&1
ENC_STATUS=$?

if [ $ENC_STATUS -eq 0 ] && [ -f encoded.png ] && grep -q "ENCODE_OK" encode.log; then
    echo "TASK1_ENCODE_IMAGE_PASS"
    TASK1=1
else
    echo "TASK1_ENCODE_IMAGE_FAIL"
fi

echo
echo "[Task 2] Decode encoded.png and detect secret header"
python3 decode.py encoded.png recovered.txt > decode.log 2>&1
DEC_STATUS=$?

if [ $DEC_STATUS -eq 0 ] && grep -q "HEADER_OK" decode.log; then
    echo "TASK2_HEADER_DETECTED_PASS"
    TASK2=1
else
    echo "TASK2_HEADER_DETECTED_FAIL"
fi

echo
echo "[Task 3] Verify SHA-256 of hidden payload"

if [ $DEC_STATUS -eq 0 ] && grep -q "SHA256_OK" decode.log; then
    echo "TASK3_HASH_VALID_PASS"
    TASK3=1
else
    echo "TASK3_HASH_VALID_FAIL"
fi

echo
echo "[Task 4] Compare recovered.txt with secret.txt"

if [ -f recovered.txt ] && cmp -s secret.txt recovered.txt; then
    echo "TASK4_RECOVERED_MATCH_PASS"
    TASK4=1
else
    echo "TASK4_RECOVERED_MATCH_FAIL"
fi

echo
echo "[Task 5] Decode image without secret header"
python3 decode.py no_secret.png recovered_empty.txt > no_header.log 2>&1
NEG_STATUS=$?

if [ $NEG_STATUS -eq 3 ] && grep -q "NO_SECRET_HEADER" no_header.log; then
    echo "TASK5_NEGATIVE_TEST_PASS"
    TASK5=1
else
    echo "TASK5_NEGATIVE_TEST_FAIL"
fi

echo
echo "[Task 6] Capacity analysis"

if [ -f analysis.txt ] \
   && grep -q "^capacity_bits=196608$" analysis.txt \
   && grep -q "^capacity_bytes=24576$" analysis.txt \
   && grep -q "^header_bytes=44$" analysis.txt \
   && grep -q "^max_payload_bytes=24532$" analysis.txt; then
    echo "TASK6_CAPACITY_ANALYSIS_PASS"
    TASK6=1
else
    echo "TASK6_CAPACITY_ANALYSIS_FAIL"
fi

echo
echo "===== TASK SUMMARY ====="
echo "task1_encode_image=$TASK1"
echo "task2_header_detected=$TASK2"
echo "task3_hash_valid=$TASK3"
echo "task4_recovered_match=$TASK4"
echo "task5_negative_test=$TASK5"
echo "task6_capacity_analysis=$TASK6"

echo
if [ $TASK1 -eq 1 ] \
   && [ $TASK2 -eq 1 ] \
   && [ $TASK3 -eq 1 ] \
   && [ $TASK4 -eq 1 ] \
   && [ $TASK5 -eq 1 ] \
   && [ $TASK6 -eq 1 ]; then
    echo "ALL_TASKS_PASS"
else
    echo "SOME_TASKS_FAIL"
fi
