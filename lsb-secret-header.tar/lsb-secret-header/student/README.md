# Lab: Giau tin bang LSB + header bi mat

## 1. Muc tieu

Trong bai lab nay, ban can hoan thien hai chuong trinh:

- encode.py
- decode.py

`encode.py` dung de giau noi dung file `secret.txt` vao anh `cover.png`.

`decode.py` dung de trich xuat thong diep bi mat tu anh da giau tin.

## 2. Ky thuat LSB

Anh RGB gom nhieu pixel. Moi pixel gom 3 kenh mau: R, G, B.

Moi kenh mau co 8 bit. Ky thuat LSB giau du lieu vao bit cuoi cung cua tung kenh mau.

Vi du gia tri ban dau la `11010110`. Neu muon giau bit 1 thi doi thanh `11010111`; neu muon giau bit 0 thi giu `11010110`.

Do chi thay doi bit cuoi cung nen anh sau khi giau tin nhin gan nhu khong doi.

## 3. Dinh dang du lieu can giau

Ban khong giau truc tiep thong diep, ma phai tao packet theo dinh dang:

```text
[MAGIC 8 bytes][LENGTH 4 bytes][SHA256 32 bytes][PAYLOAD]
```

Trong do:

- `MAGIC` la header bi mat: `PTITLSB1`
- `LENGTH` la do dai cua `PAYLOAD`, luu bang 4 bytes big-endian.
- `SHA256` la ma bam SHA-256 cua `PAYLOAD`.
- `PAYLOAD` la noi dung bi mat can giau.

## 4. Cong thuc tinh dung luong

Anh RGB co `width * height` pixel. Moi pixel co 3 kenh mau. Moi kenh giau duoc 1 bit.

```text
capacity_bits = width * height * 3
capacity_bytes = capacity_bits / 8
```

Voi anh 256x256:

```text
capacity_bits = 256 * 256 * 3 = 196608 bits
capacity_bytes = 196608 / 8 = 24576 bytes
```

Header co kich thuoc:

```text
MAGIC 8 bytes + LENGTH 4 bytes + SHA256 32 bytes = 44 bytes
```

Payload toi da:

```text
max_payload_bytes = 24576 - 44 = 24532 bytes
```

## 5. Nhiem vu

Ban can hoan thanh cac task sau:

Task 1: Viet `encode.py` de tao duoc `encoded.png`.

Task 2: Viet `decode.py` de phat hien duoc header bi mat.

Task 3: Kiem tra SHA-256 cua payload.

Task 4: Trich xuat duoc thong diep goc ra `recovered.txt`.

Task 5: Khi decode anh `no_secret.png`, chuong trinh phai in `NO_SECRET_HEADER`.

Task 6: Tao file `analysis.txt` co cac dong sau:

```text
capacity_bits=196608
capacity_bytes=24576
header_bytes=44
max_payload_bytes=24532
```

## 6. Cach chay

Sau khi hoan thien chuong trinh, chay:

```bash
bash check_work.sh
```

Neu dung, ban se thay:

```text
TASK1_ENCODE_IMAGE_PASS
TASK2_HEADER_DETECTED_PASS
TASK3_HASH_VALID_PASS
TASK4_RECOVERED_MATCH_PASS
TASK5_NEGATIVE_TEST_PASS
TASK6_CAPACITY_ANALYSIS_PASS
ALL_TASKS_PASS
```
