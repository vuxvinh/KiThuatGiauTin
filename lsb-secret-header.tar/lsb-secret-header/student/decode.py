#!/usr/bin/env python3
from PIL import Image
import hashlib
import struct
import sys

MAGIC = b"PTITLSB1"
HEADER_SIZE = 8 + 4 + 32


def image_lsb_bits(img: Image.Image):
    """
    TODO:
    Duyet pixel tu trai sang phai, tu tren xuong duoi.
    Voi moi pixel, lay LSB cua R, G, B.
    """
    raise NotImplementedError("TODO: image_lsb_bits")


def bits_to_bytes(bits):
    """
    TODO:
    Gom moi 8 bit thanh 1 byte.
    Bit dau tien la bit co trong so cao nhat.
    """
    raise NotImplementedError("TODO: bits_to_bytes")


def read_bytes_from_lsb(img: Image.Image, nbytes: int) -> bytes:
    """
    TODO:
    Doc nbytes tu LSB cua anh.
    """
    raise NotImplementedError("TODO: read_bytes_from_lsb")


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 decode.py <image.png> <output.txt>")
        sys.exit(1)

    image_path = sys.argv[1]
    output_path = sys.argv[2]

    img = Image.open(image_path).convert("RGB")

    header = read_bytes_from_lsb(img, HEADER_SIZE)

    magic = header[:8]
    if magic != MAGIC:
        print("NO_SECRET_HEADER")
        sys.exit(3)

    length = struct.unpack(">I", header[8:12])[0]
    expected_digest = header[12:44]

    total_bytes = HEADER_SIZE + length
    capacity_bytes = (img.width * img.height * 3) // 8

    if total_bytes > capacity_bytes:
        print("ERROR: declared payload length exceeds image capacity")
        sys.exit(5)

    all_data = read_bytes_from_lsb(img, total_bytes)
    payload = all_data[HEADER_SIZE:]

    actual_digest = hashlib.sha256(payload).digest()

    print("HEADER_OK")
    print(f"payload_bytes={length}")

    if actual_digest != expected_digest:
        print("SHA256_FAIL")
        sys.exit(4)

    with open(output_path, "wb") as f:
        f.write(payload)

    print("SHA256_OK")
    print("DECODE_OK")
    print(f"output={output_path}")


if __name__ == "__main__":
    main()
