#!/usr/bin/env python3
from PIL import Image
import hashlib
import struct
import sys

MAGIC = b"PTITLSB1"
HEADER_SIZE = 8 + 4 + 32


def bytes_to_bits(data: bytes):
    for byte in data:
        for shift in range(7, -1, -1):
            yield (byte >> shift) & 1


def build_packet(payload: bytes) -> bytes:
    """
    TODO:
    Tao packet theo dinh dang:
    [MAGIC 8 bytes][LENGTH 4 bytes][SHA256 32 bytes][PAYLOAD]

    Goi y:
    length_bytes = struct.pack(">I", len(payload))
    digest = hashlib.sha256(payload).digest()
    """
    raise NotImplementedError("TODO: build_packet")


def capacity_bits(img: Image.Image) -> int:
    """
    TODO:
    Anh RGB giau duoc width * height * 3 bit.
    """
    raise NotImplementedError("TODO: capacity_bits")


def embed_packet(img: Image.Image, packet: bytes) -> Image.Image:
    """
    TODO:
    - Chuyen anh sang RGB.
    - Lay toan bo pixel.
    - Voi moi bit cua packet, thay LSB cua tung kenh mau.
    - Tra ve anh moi.
    """
    raise NotImplementedError("TODO: embed_packet")


def main():
    if len(sys.argv) != 4:
        print("Usage: python3 encode.py <cover.png> <secret.txt> <encoded.png>")
        sys.exit(1)

    cover_path = sys.argv[1]
    secret_path = sys.argv[2]
    output_path = sys.argv[3]

    img = Image.open(cover_path).convert("RGB")
    payload = open(secret_path, "rb").read()

    packet = build_packet(payload)
    cap = capacity_bits(img)
    used = len(packet) * 8

    if used > cap:
        print(f"ERROR: payload too large. need_bits={used} capacity_bits={cap}")
        sys.exit(2)

    stego = embed_packet(img, packet)
    stego.save(output_path)

    print("ENCODE_OK")
    print(f"payload_bytes={len(payload)}")
    print(f"header_bytes={HEADER_SIZE}")
    print(f"used_bits={used}")
    print(f"capacity_bits={cap}")
    print(f"output={output_path}")


if __name__ == "__main__":
    main()
