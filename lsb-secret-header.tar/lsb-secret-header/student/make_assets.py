from PIL import Image
from pathlib import Path
import shutil

WIDTH = 256
HEIGHT = 256


def make_cover(path: str) -> None:
    img = Image.new("RGB", (WIDTH, HEIGHT))

    for y in range(HEIGHT):
        for x in range(WIDTH):
            r = (3 * x + y) % 256
            g = (x + 2 * y) % 256
            b = (x ^ y) % 256
            img.putpixel((x, y), (r, g, b))

    img.save(path)


def main() -> None:
    make_cover("cover.png")
    shutil.copyfile("cover.png", "no_secret.png")

    secret = (
        "FLAG{LSB_HEADER_FOUND}\n"
        "Thong diep nay duoc giau bang LSB va duoc danh dau bang header bi mat.\n"
    )

    Path("secret.txt").write_text(secret, encoding="utf-8")

    print("Created cover.png, no_secret.png, secret.txt")


if __name__ == "__main__":
    main()
