#!/usr/bin/env python3
from PIL import Image
import hashlib
import struct
import sys

MAGIC = b"PTITLSB1"
HEADER_SIZE = 8 + 4 + 32


def bytes_to_bits(data: bytes):
    for byte in data:
        for shift in range(7, -1, -1):
            yield (byte >> shift) & 1


def build_packet(payload: bytes) -> bytes:
    length_bytes = struct.pack(">I", len(payload))
    digest = hashlib.sha256(payload).digest()
    return MAGIC + length_bytes + digest + payload


def capacity_bits(img: Image.Image) -> int:
    return img.width * img.height * 3


def embed_packet(img: Image.Image, packet: bytes) -> Image.Image:
    img = img.convert("RGB")
    pixels = list(img.getdata())

    channels = []
    for r, g, b in pixels:
        channels.extend([r, g, b])

    bits = list(bytes_to_bits(packet))

    if len(bits) > len(channels):
        raise ValueError("Packet is too large for this image")

    for i, bit in enumerate(bits):
        channels[i] = (channels[i] & 0xFE) | bit

    new_pixels = []
    for i in range(0, len(channels), 3):
        new_pixels.append((channels[i], channels[i + 1], channels[i + 2]))

    out = Image.new("RGB", img.size)
    out.putdata(new_pixels)
    return out


def main():
    if len(sys.argv) != 4:
        print("Usage: python3 encode.py <cover.png> <secret.txt> <encoded.png>")
        sys.exit(1)

    cover_path = sys.argv[1]
    secret_path = sys.argv[2]
    output_path = sys.argv[3]

    img = Image.open(cover_path).convert("RGB")
    payload = open(secret_path, "rb").read()

    packet = build_packet(payload)
    cap = capacity_bits(img)
    used = len(packet) * 8

    if used > cap:
        print(f"ERROR: payload too large. need_bits={used} capacity_bits={cap}")
        sys.exit(2)

    stego = embed_packet(img, packet)
    stego.save(output_path)

    print("ENCODE_OK")
    print(f"payload_bytes={len(payload)}")
    print(f"header_bytes={HEADER_SIZE}")
    print(f"used_bits={used}")
    print(f"capacity_bits={cap}")
    print(f"output={output_path}")


if __name__ == "__main__":
    main()
