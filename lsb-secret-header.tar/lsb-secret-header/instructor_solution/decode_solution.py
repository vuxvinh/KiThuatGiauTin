#!/usr/bin/env python3
from PIL import Image
import hashlib
import struct
import sys

MAGIC = b"PTITLSB1"
HEADER_SIZE = 8 + 4 + 32


def image_lsb_bits(img: Image.Image):
    img = img.convert("RGB")
    for r, g, b in img.getdata():
        yield r & 1
        yield g & 1
        yield b & 1


def bits_to_bytes(bits):
    data = bytearray()

    for i in range(0, len(bits), 8):
        chunk = bits[i:i + 8]

        if len(chunk) < 8:
            break

        value = 0
        for bit in chunk:
            value = (value << 1) | bit

        data.append(value)

    return bytes(data)


def read_bytes_from_lsb(img: Image.Image, nbytes: int) -> bytes:
    need_bits = nbytes * 8
    bits = []

    for bit in image_lsb_bits(img):
        bits.append(bit)

        if len(bits) == need_bits:
            break

    if len(bits) < need_bits:
        raise ValueError("Image does not contain enough LSB bits")

    return bits_to_bytes(bits)


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 decode.py <image.png> <output.txt>")
        sys.exit(1)

    image_path = sys.argv[1]
    output_path = sys.argv[2]

    img = Image.open(image_path).convert("RGB")

    header = read_bytes_from_lsb(img, HEADER_SIZE)

    magic = header[:8]
    if magic != MAGIC:
        print("NO_SECRET_HEADER")
        sys.exit(3)

    length = struct.unpack(">I", header[8:12])[0]
    expected_digest = header[12:44]

    total_bytes = HEADER_SIZE + length
    capacity_bytes = (img.width * img.height * 3) // 8

    if total_bytes > capacity_bytes:
        print("ERROR: declared payload length exceeds image capacity")
        sys.exit(5)

    all_data = read_bytes_from_lsb(img, total_bytes)
    payload = all_data[HEADER_SIZE:]

    actual_digest = hashlib.sha256(payload).digest()

    print("HEADER_OK")
    print(f"payload_bytes={length}")

    if actual_digest != expected_digest:
        print("SHA256_FAIL")
        sys.exit(4)

    with open(output_path, "wb") as f:
        f.write(payload)

    print("SHA256_OK")
    print("DECODE_OK")
    print(f"output={output_path}")


if __name__ == "__main__":
    main()
