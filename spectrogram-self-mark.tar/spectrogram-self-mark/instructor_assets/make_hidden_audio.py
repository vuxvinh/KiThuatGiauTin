#!/usr/bin/env python3
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy.io import wavfile

SAMPLE_RATE = 44100
DURATION_SECONDS = 7.0
OUTPUT_WAV = "../student/hidden.wav"

HIDDEN_TEXT = "LABTAINER2026"

FREQ_MIN = 1200
FREQ_MAX = 9000

IMAGE_WIDTH = 420
IMAGE_HEIGHT = 90

AMPLITUDE = 0.22
RANDOM_SEED = 2026


def load_font(size: int):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "C:/Windows/Fonts/arialbd.ttf",
        "C:/Windows/Fonts/Arialbd.ttf",
    ]

    for path in candidates:
        try:
            return ImageFont.truetype(path, size)
        except Exception:
            pass

    return ImageFont.load_default()


def make_text_mask(text: str) -> np.ndarray:
    img = Image.new("L", (IMAGE_WIDTH, IMAGE_HEIGHT), 0)
    draw = ImageDraw.Draw(img)
    font = load_font(42)

    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]

    x = (IMAGE_WIDTH - text_width) // 2
    y = (IMAGE_HEIGHT - text_height) // 2 - 4

    draw.text((x, y), text, fill=255, font=font)

    arr = np.array(img)
    mask = arr > 128

    return mask


def synthesize_audio_from_mask(mask: np.ndarray) -> np.ndarray:
    rng = np.random.default_rng(RANDOM_SEED)
    total_samples = int(SAMPLE_RATE * DURATION_SECONDS)
    audio = np.zeros(total_samples, dtype=np.float64)

    rows, cols = mask.shape
    samples_per_col = total_samples // cols
    window = np.hanning(samples_per_col)

    for col in range(cols):
        start = col * samples_per_col
        end = start + samples_per_col

        if end > total_samples:
            break

        active_rows = np.where(mask[:, col])[0]

        if len(active_rows) == 0:
            continue

        t = np.arange(samples_per_col) / SAMPLE_RATE
        segment = np.zeros(samples_per_col, dtype=np.float64)

        for row in active_rows:
            normalized = 1.0 - (row / max(1, rows - 1))
            freq = FREQ_MIN + normalized * (FREQ_MAX - FREQ_MIN)
            segment += np.sin(2 * np.pi * freq * t)

        segment = segment / max(1, len(active_rows))
        audio[start:end] += segment * window

    noise = rng.normal(0, 0.015, size=audio.shape)
    audio += noise

    max_abs = np.max(np.abs(audio))
    if max_abs > 0:
        audio = audio / max_abs

    audio = audio * AMPLITUDE

    return audio


def main():
    mask = make_text_mask(HIDDEN_TEXT)
    audio = synthesize_audio_from_mask(mask)

    audio_int16 = np.int16(audio * 32767)
    wavfile.write(OUTPUT_WAV, SAMPLE_RATE, audio_int16)

    print(f"Created {OUTPUT_WAV}")
    print(f"Hidden text: {HIDDEN_TEXT}")


if __name__ == "__main__":
    main()
