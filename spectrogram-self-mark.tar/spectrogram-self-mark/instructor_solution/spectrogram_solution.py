#!/usr/bin/env python3
import sys

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
from scipy.io import wavfile


def normalize_audio(data):
    if data.ndim > 1:
        data = data.mean(axis=1)

    if data.dtype == np.int16:
        return data.astype(np.float32) / 32768.0

    if data.dtype == np.int32:
        return data.astype(np.float32) / 2147483648.0

    if data.dtype == np.uint8:
        return (data.astype(np.float32) - 128.0) / 128.0

    data = data.astype(np.float32)
    max_abs = np.max(np.abs(data))
    if max_abs > 0:
        data = data / max_abs

    return data


def create_spectrogram(sample_rate, audio, output_png):
    plt.figure(figsize=(12, 4.5), dpi=140)
    plt.specgram(
        audio,
        NFFT=1024,
        Fs=sample_rate,
        noverlap=768,
        cmap="magma",
    )
    plt.ylim(0, 10000)
    plt.xlabel("Time (s)")
    plt.ylabel("Frequency (Hz)")
    plt.title("Hidden spectrogram self-mark")
    plt.colorbar(label="Intensity (dB)")
    plt.tight_layout()
    plt.savefig(output_png)
    plt.close()


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 spectrogram.py <input.wav> <output.png>")
        sys.exit(1)

    input_wav = sys.argv[1]
    output_png = sys.argv[2]

    sample_rate, data = wavfile.read(input_wav)
    audio = normalize_audio(data)

    create_spectrogram(sample_rate, audio, output_png)

    print("SPECTROGRAM_OK")
    print(f"input={input_wav}")
    print(f"output={output_png}")


if __name__ == "__main__":
    main()
