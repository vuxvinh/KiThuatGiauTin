# Lab: Giấu tin trong spectrogram + tự đánh dấu bằng mẫu hình ảnh

## 1. Mục tiêu

Trong bài lab này, bạn sẽ phân tích một file audio có tên:

```text
hidden.wav
```

Khi nghe bằng tai, file audio này nghe giống tiếng nhiễu hoặc âm thanh lạ. Tuy nhiên, khi quan sát bằng spectrogram, bạn sẽ thấy một thông điệp ẩn trong miền tần số.

## 2. Spectrogram là gì?

Spectrogram là biểu diễn trực quan của tín hiệu âm thanh theo thời gian và tần số.

- Trục ngang thường là thời gian.
- Trục dọc thường là tần số.
- Màu sắc hoặc độ sáng thể hiện cường độ tín hiệu tại tần số đó.

Một file audio có thể được tạo sao cho khi nhìn bằng spectrogram sẽ hiện ra chữ hoặc hình.

## 3. Tự đánh dấu trong bài này là gì?

Trong bài lab này, file audio tự mang dấu hiệu nhận diện của nó. Dấu hiệu đó không nằm ở tên file và cũng không nằm trong metadata. Dấu hiệu nằm trực tiếp trong phổ tần số của audio.

Khi bạn mở spectrogram, thông điệp hoặc mẫu hình ảnh hiện ra. Đó chính là self-mark.

## 4. Các file được cung cấp

```text
hidden.wav
spectrogram.py
answer.txt
explanation.txt
check_work.sh
```

Trong đó:

- `hidden.wav` là file audio chứa thông điệp ẩn.
- `spectrogram.py` là chương trình bạn cần hoàn thiện để tạo ảnh spectrogram.
- `answer.txt` là nơi bạn ghi thông điệp quan sát được.
- `explanation.txt` là nơi bạn giải thích ngắn về self-marking.
- `check_work.sh` là script kiểm tra từng task.

## 5. Nhiệm vụ

Task 1: Kiểm tra file `hidden.wav` là file audio WAV hợp lệ.

Task 2: Hoàn thiện `spectrogram.py` để tạo ảnh `spectrogram.png` từ `hidden.wav`.

Task 3: Quan sát `spectrogram.png` và ghi thông điệp ẩn vào file `answer.txt`.

Task 4: Viết giải thích ngắn vào file `explanation.txt` về việc self-mark nằm ở đâu.

## 6. Cách chạy

Bước 1: Kiểm tra file audio:

```bash
file hidden.wav
```

Bước 2: Tạo spectrogram:

```bash
python3 spectrogram.py hidden.wav spectrogram.png
```

Bước 3: Mở hoặc xem file `spectrogram.png`. Nếu chạy trong môi trường có giao diện, có thể mở ảnh bằng trình xem ảnh. Nếu không có giao diện, có thể copy file ra ngoài máy host để xem.

Bước 4: Tạo file `answer.txt`:

```bash
nano answer.txt
```

Chỉ ghi thông điệp bạn nhìn thấy, không ghi thêm câu giải thích.

Bước 5: Tạo file `explanation.txt`:

```bash
nano explanation.txt
```

Viết ngắn gọn self-mark nằm ở đâu và vì sao nghe file audio thông thường khó phát hiện thông điệp.

Bước 6: Chạy kiểm tra:

```bash
bash check_work.sh
```

Nếu làm đúng, bạn sẽ thấy:

```text
TASK1_AUDIO_FILE_PASS
TASK2_SPECTROGRAM_PASS
TASK3_HIDDEN_MESSAGE_PASS
TASK4_EXPLANATION_PASS
ALL_TASKS_PASS
```
