#!/bin/bash
set -u

echo "===== SPECTROGRAM SELF-MARK LAB CHECK ====="
echo

TASK1=0
TASK2=0
TASK3=0
TASK4=0

EXPECTED_HASH="3d743aa6299de5370728cb911af4546f2888f5aa21248a38e2bacc0dba2e4940"

rm -f spectrogram.log

echo "[Task 1] Check hidden.wav audio file"

if [ -f hidden.wav ] && file hidden.wav | grep -qi "WAVE audio"; then
    echo "TASK1_AUDIO_FILE_PASS"
    TASK1=1
else
    echo "TASK1_AUDIO_FILE_FAIL"
fi

echo
echo "[Task 2] Generate spectrogram.png"

python3 spectrogram.py hidden.wav spectrogram.png > spectrogram.log 2>&1
SPEC_STATUS=$?

if [ $SPEC_STATUS -eq 0 ] \
   && [ -f spectrogram.png ] \
   && grep -q "SPECTROGRAM_OK" spectrogram.log; then
    echo "TASK2_SPECTROGRAM_PASS"
    TASK2=1
else
    echo "TASK2_SPECTROGRAM_FAIL"
fi

echo
echo "[Task 3] Check hidden message answer"

if [ -f answer.txt ]; then
    NORMALIZED_ANSWER=$(cat answer.txt | tr -d ' \t\r\n' | tr '[:lower:]' '[:upper:]')
    ANSWER_HASH=$(printf "%s" "$NORMALIZED_ANSWER" | sha256sum | awk '{print $1}')

    if [ "$ANSWER_HASH" = "$EXPECTED_HASH" ]; then
        echo "TASK3_HIDDEN_MESSAGE_PASS"
        TASK3=1
    else
        echo "TASK3_HIDDEN_MESSAGE_FAIL"
    fi
else
    echo "TASK3_HIDDEN_MESSAGE_FAIL"
fi

echo
echo "[Task 4] Check explanation"

if [ -f explanation.txt ] \
   && grep -Eqi "spectrogram" explanation.txt \
   && grep -Eqi "tần số|tan so|frequency" explanation.txt; then
    echo "TASK4_EXPLANATION_PASS"
    TASK4=1
else
    echo "TASK4_EXPLANATION_FAIL"
fi

echo
echo "===== TASK SUMMARY ====="
echo "task1_audio_file=$TASK1"
echo "task2_spectrogram=$TASK2"
echo "task3_hidden_message=$TASK3"
echo "task4_explanation=$TASK4"

echo
if [ $TASK1 -eq 1 ] \
   && [ $TASK2 -eq 1 ] \
   && [ $TASK3 -eq 1 ] \
   && [ $TASK4 -eq 1 ]; then
    echo "ALL_TASKS_PASS"
else
    echo "SOME_TASKS_FAIL"
fi
