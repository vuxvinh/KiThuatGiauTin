#!/usr/bin/env python3
import sys

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
from scipy.io import wavfile


def normalize_audio(data):
    raise NotImplementedError("TODO: normalize_audio")


def create_spectrogram(sample_rate, audio, output_png):
    raise NotImplementedError("TODO: create_spectrogram")


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 spectrogram.py <input.wav> <output.png>")
        sys.exit(1)

    input_wav = sys.argv[1]
    output_png = sys.argv[2]

    sample_rate, data = wavfile.read(input_wav)
    audio = normalize_audio(data)

    create_spectrogram(sample_rate, audio, output_png)

    print("SPECTROGRAM_OK")
    print(f"input={input_wav}")
    print(f"output={output_png}")


if __name__ == "__main__":
    main()
